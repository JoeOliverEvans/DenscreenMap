﻿using System;
using System.Net.Http;
using DenscreenMap.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json;

namespace DenscreenMap.Pages
{
    public class IndexModel : PageModel
    {
        public async void OnGet()
        {
            
        }
    }
}